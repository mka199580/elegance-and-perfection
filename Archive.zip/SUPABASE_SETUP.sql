-- Run this once in Supabase SQL Editor.
create table if not exists products (
  id bigint generated always as identity primary key,
  created_at timestamp with time zone default now(),
  name text,
  name_ar text,
  brand text,
  description text,
  description_ar text,
  price text,
  available boolean default true,
  images jsonb default '[]'::jsonb,
  views bigint default 0
);

alter table products enable row level security;

drop policy if exists "Public read access" on products;
drop policy if exists "Public insert access" on products;
drop policy if exists "Public update access" on products;
drop policy if exists "Public delete access" on products;

create policy "Public read access" on products for select using (true);
create policy "Public insert access" on products for insert with check (true);
create policy "Public update access" on products for update using (true);
create policy "Public delete access" on products for delete using (true);
